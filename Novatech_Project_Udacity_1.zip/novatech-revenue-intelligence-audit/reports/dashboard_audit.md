# Dashboard audit

Subject: three QuickSight sheets (PDF exports dated 1 September 2026) and the repository README, commit `c891ad4` of the [original project](https://github.com/Chiragchhabra1127/revenue-intelligence-dashboard).

## 1. Root cause: many-to-many fan-out

The unified dataset is `CRM LEFT JOIN marketing LEFT JOIN support`, each on `account_id`. All three tables have repeated account IDs. An account with *d* deals, *l* leads and *t* tickets produces *d × l × t* rows (using 1 where it has no leads or tickets). The result is 63,420 rows from 499 deals. Lead counts are very uneven (median 5 per CRM account, maximum 1,035), so accounts are weighted very differently. This distorts averages, rates and rankings, not only totals.

Row-by-row figures: [`tables/audit_reconciliation.csv`](tables/audit_reconciliation.csv). All 13 tested KPIs match the displayed values when rebuilt from the join, at display precision.

![Response rate: joined vs raw](figures/02_response_rate.png)

## 2. Other issues

| Issue | Detail | Fix |
|---|---|---|
| "Pipeline value" label | Lost deals are all 0 and there are no open deals, so the sum is won value | Rename to "Won value" |
| Deal value by pipeline stage | Only Won and Lost exist, and Lost is always 0 | Replace with win/loss counts |
| Loss reason chart | The large `empty` slice is rows with no loss reason; in the raw data these are exactly the won deals | Filter to Lost |
| Average tickets per customer (3.37) | It is the mean of `tickets_last_30_days` over joined rows; the raw ticket-row mean is 3.70. Neither is tickets per customer | Define the measure, then calculate at account grain |
| Distinct counts | 3 `opportunity_id` and 4 `ticket_id` values are reused across accounts | Confirm with the data owner; count rows until resolved |
| Orphan accounts | A CRM-anchored join drops 204 support rows and 150 marketing rows | Keep source tables separate for source-level KPIs |
| README Q&A check | It says six answers matched the dashboard. For example, 3,000 tickets and 499 deals differ from the dashboard's 2.79K and 496. The six answers do match the raw files | Compare like with like |

## 3. Requirements brief coverage

Based on the PDF exports and the README's visual list. The live QuickSight analysis was not available, so interactive features such as drill-down could not be tested.

| Requested | Found in dashboard exports | In this reanalysis |
|---|---|---|
| Resolution time by priority | Not found | Yes |
| At-risk accounts | Not found | Yes (screening rule) |
| Ticket volume by account against revenue | Not found | Yes |
| Win rate by region, rep, product | Overall only | Yes |
| Average deal value by product, segment, region | Overall only | Yes (result tables) |
| Days-to-close trend | Not found | Yes (inconclusive) |
| Date, campaign name and customer segment filters | Not among the visible controls | Not applicable (static analysis) |

## 4. Recommended model

Use separate CRM, marketing and support fact tables with a shared account dimension. If the tool needs one flat dataset, aggregate each fact table to one row per account first (see [`../sql/account_summary.sql`](../sql/account_summary.sql)). That flat table cannot support ticket-level or lead-level filters. Marketing segment and support tier vary within most accounts, so do not treat them as account attributes.

## Not audited

The written business report, completed Q exploration log, Q Topic settings and exportable dashboard definition were not among the files reviewed.
