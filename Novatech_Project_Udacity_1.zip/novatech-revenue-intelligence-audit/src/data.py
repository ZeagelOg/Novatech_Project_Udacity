"""Load the three raw tables and run data-quality checks."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"

FILES = {
    "crm": ("novatech_crm_deals.csv", ["deal_created_date", "deal_closed_date"]),
    "mkt": ("novatech_marketing_campaigns.csv", ["campaign_date"]),
    "sup": ("novatech_support_tickets.csv", ["ticket_created_date", "ticket_resolved_date"]),
}


def load(raw: Path = RAW) -> dict:
    missing = [f for f, _ in FILES.values() if not (raw / f).exists()]
    if missing:
        raise FileNotFoundError(f"Missing in {raw}: {missing}. See data/README.md.")
    t = {k: pd.read_csv(raw / f, parse_dates=d) for k, (f, d) in FILES.items()}
    t["crm"]["won"] = t["crm"].deal_stage.eq("Won")
    t["crm"]["days_to_close"] = (t["crm"].deal_closed_date - t["crm"].deal_created_date).dt.days
    t["sup"]["resolution_hours"] = (
        t["sup"].ticket_resolved_date - t["sup"].ticket_created_date
    ).dt.total_seconds() / 3600
    return t


def quality_checks(t: dict) -> pd.DataFrame:
    c, m, s = t["crm"], t["mkt"], t["sup"]
    crm_ids = set(c.account_id)
    repeated = lambda df, col: int(df[col].duplicated().sum())
    varying = lambda df, col: int((df.groupby("account_id")[col].nunique() > 1).sum())
    rows = [
        ("Reused opportunity_id (extra rows)", repeated(c, "opportunity_id")),
        ("Reused ticket_id (extra rows)", repeated(s, "ticket_id")),
        ("Repeated lead_id (extra rows)", repeated(m, "lead_id")),
        ("Marketing rows with no CRM account", int((~m.account_id.isin(crm_ids)).sum())),
        ("Support rows with no CRM account", int((~s.account_id.isin(crm_ids)).sum())),
        ("Unresolved tickets", int(s.ticket_resolved_date.isna().sum())),
        ("Tickets with blank sentiment", int(s.customer_sentiment.isna().sum())),
        ("Leads with blank annual_income", int(m.annual_income.isna().sum())),
        ("Deals closed before created", int((c.days_to_close < 0).sum())),
        ("Tickets resolved before created", int((s.resolution_hours < 0).sum())),
        ("Lost deals with non-zero value", int((~c.won & c.deal_value.ne(0)).sum())),
        ("Accounts with >1 support customer_tier", varying(s, "customer_tier")),
        ("Accounts with >1 support region", varying(s, "region")),
        ("Accounts with >1 marketing customer_segment", varying(m, "customer_segment")),
        ("Non-responders with attributed revenue", int((m.campaign_response.eq(0) & m.revenue_attributed.gt(0)).sum())),
        ("Qualified Leads who responded", int((m.funnel_stage.eq("Qualified Lead") & m.campaign_response.eq(1)).sum())),
        ("Opportunity/Closed Won leads who did not respond", int((m.funnel_stage.isin(["Opportunity", "Closed Won"]) & m.campaign_response.eq(0)).sum())),
    ]
    return pd.DataFrame(rows, columns=["check", "count"])
