"""Rebuild the original dashboard's join and reconcile its KPIs."""
import pandas as pd
from .metrics import headline


def fanout_join(t):
    """CRM LEFT JOIN marketing LEFT JOIN support, all on account_id."""
    return (
        t["crm"].merge(t["mkt"].drop(columns="data_source"), on="account_id", how="left")
        .merge(t["sup"].drop(columns="data_source"), on="account_id", how="left")
    )


# Values as displayed on the original dashboard PDF exports (1 Sep 2026).
DISPLAYED = [
    ("Deal value ($)", "100.9M", "won_value"),
    ("Opportunity count", "496", "deals"),
    ("Average deal size ($)", "1.59K", "avg_value_all_deals"),
    ("Average days to close", "62.18", "avg_days_to_close"),
    ("Win rate (%)", "63.75", "win_rate_pct"),
    ("Campaign spend ($)", "353.51M", "campaign_spend"),
    ("Attributed revenue ($)", "25.05M", "revenue_attributed"),
    ("Campaign ROI (%)", "-92.91", "roi_pct"),
    ("Campaign responses", "14.1K", "campaign_responses"),
    ("Support tickets", "2.79K", "tickets"),
    ("Complaints", "172", "complaints"),
    ("Users affected", "13.74M", "users_affected"),
    ("Downtime minutes", "1.24M", "downtime_minutes"),
]


def reproduced(j):
    """Each KPI as computed on the fanned-out table."""
    return {
        "won_value": j.deal_value.sum(),
        "deals": j.opportunity_id.nunique(),
        "avg_value_all_deals": j.deal_value.mean(),
        "avg_days_to_close": j.days_to_close.mean(),
        "win_rate_pct": j.won.mean() * 100,
        "campaign_spend": j.campaign_spend.sum(),
        "revenue_attributed": j.revenue_attributed.sum(),
        # Ratio of sums on the joined table; matches the displayed value.
        "roi_pct": (j.revenue_attributed.sum() / j.campaign_spend.sum() - 1) * 100,
        "campaign_responses": j.campaign_response.sum(),
        "tickets": j.ticket_id.nunique(),
        "complaints": j.complaint_flag.sum(),
        "users_affected": j.users_affected.sum(),
        "downtime_minutes": j.downtime_minutes.sum(),
    }


def reconciliation(t):
    j = fanout_join(t)
    rep, raw = reproduced(j), headline(t)
    return pd.DataFrame(
        [(label, shown, rep[k], raw[k]) for label, shown, k in DISPLAYED],
        columns=["metric", "dashboard_shows", "rebuilt_from_fanout_join", "correct_from_raw"],
    )


def roi_by_campaign_compare(t):
    j = fanout_join(t)
    def roi(df):
        g = df.groupby("campaign_name")[["revenue_attributed", "campaign_spend"]].sum()
        return (g.revenue_attributed / g.campaign_spend - 1) * 100
    return pd.DataFrame({"fanout_join_roi_pct": roi(j), "raw_roi_pct": roi(t["mkt"])}).reset_index()


def response_rate_compare(t):
    j = fanout_join(t)
    return pd.DataFrame({
        "fanout_join_pct": j.groupby("campaign_channel").campaign_response.mean() * 100,
        "raw_pct": t["mkt"].groupby("campaign_channel").campaign_response.mean() * 100,
    }).reset_index()
