import sqlite3

import pandas as pd
import pytest

from src import audit, metrics as mx
from src.data import ROOT, load


@pytest.fixture(scope="module")
def t():
    return load()


@pytest.fixture(scope="module")
def sql_result(t):
    con = sqlite3.connect(":memory:")
    for name in ("crm", "mkt", "sup"):
        t[name].to_sql(name, con, index=False)
    return pd.read_sql((ROOT / "sql" / "account_summary.sql").read_text(), con)


def test_row_counts(t):
    assert [len(t[k]) for k in ("crm", "mkt", "sup")] == [499, 2240, 3000]


def test_fanout_is_reproduced(t):
    j = audit.fanout_join(t)
    assert len(j) == 63420
    assert j.deal_value.sum() == pytest.approx(100_900_682)
    assert j.ticket_id.nunique() == 2792


def test_account_grain_preserves_crm_totals(t):
    a = mx.account_summary(t)
    assert a.account_id.is_unique and len(a) == t["crm"].account_id.nunique()
    assert a.won_value.sum() == pytest.approx(t["crm"].deal_value.sum())
    assert a.deals.sum() == len(t["crm"])


def test_account_grain_excludes_only_orphans(t):
    a = mx.account_summary(t)
    ids = set(t["crm"].account_id)
    assert a.tickets.sum() == t["sup"].account_id.isin(ids).sum()
    assert a.campaign_spend.sum() == pytest.approx(t["mkt"].loc[t["mkt"].account_id.isin(ids), "campaign_spend"].sum())


def test_sql_matches_pandas(t, sql_result):
    a = mx.account_summary(t).set_index("account_id").sort_index()
    q = sql_result.set_index("account_id").sort_index()
    for col in ["deals", "won_deals", "won_value", "leads", "campaign_spend", "revenue_attributed", "tickets", "negative_tickets"]:
        assert q[col].to_numpy() == pytest.approx(a[col].to_numpy().astype(float)), col
