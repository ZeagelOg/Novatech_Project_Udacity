"""All metrics are computed at each table's own grain (no row fan-out)."""
import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency


def headline(t):
    c, m, s = t["crm"], t["mkt"], t["sup"]
    return {
        "deals": len(c),
        "won_deals": int(c.won.sum()),
        "win_rate_pct": c.won.mean() * 100,
        "won_value": c.deal_value.sum(),
        "avg_value_all_deals": c.deal_value.mean(),
        "avg_value_won_deals": c.loc[c.won, "deal_value"].mean(),
        "avg_days_to_close": c.days_to_close.mean(),
        "leads": len(m),
        "campaign_responses": int(m.campaign_response.sum()),
        "response_rate_pct": m.campaign_response.mean() * 100,
        "campaign_spend": m.campaign_spend.sum(),
        "revenue_attributed": m.revenue_attributed.sum(),
        "roi_pct": (m.revenue_attributed.sum() / m.campaign_spend.sum() - 1) * 100,
        "complaints": int(m.complaint_flag.sum()),
        "tickets": len(s),
        "users_affected": int(s.users_affected.sum()),
        "downtime_minutes": int(s.downtime_minutes.sum()),
        "median_resolution_hours": s.resolution_hours.median(),
    }


def marketing_by(m, dim):
    g = m.groupby(dim).agg(
        leads=("lead_id", "size"),
        responses=("campaign_response", "sum"),
        closed_won_leads=("funnel_stage", lambda x: (x == "Closed Won").sum()),
        spend=("campaign_spend", "sum"),
        revenue=("revenue_attributed", "sum"),
    )
    g["response_rate_pct"] = g.responses / g.leads * 100
    g["closed_won_share_pct"] = g.closed_won_leads / g.leads * 100
    g["roi_pct"] = (g.revenue / g.spend - 1) * 100
    g["spend_per_closed_won_lead"] = g.spend / g.closed_won_leads
    return g.sort_values("roi_pct", ascending=False).reset_index()


def funnel_snapshot(m):
    order = ["Prospect", "Lead", "Qualified Lead", "Opportunity", "Closed Won"]
    g = m.funnel_stage.value_counts().reindex(order).rename("leads_currently_in_stage").to_frame()
    g["leads_at_or_beyond_stage"] = g.leads_currently_in_stage[::-1].cumsum()[::-1]
    g["pct_of_all_leads"] = g.leads_at_or_beyond_stage / len(m) * 100
    return g.rename_axis("funnel_stage").reset_index()


def wilson(k, n, z=1.96):
    p = k / n
    d = 1 + z**2 / n
    mid = (p + z**2 / (2 * n)) / d
    half = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / d
    return (mid - half) * 100, (mid + half) * 100


def sales_by(c, dim):
    g = c.groupby(dim).agg(
        deals=("won", "size"), won=("won", "sum"), won_value=("deal_value", "sum"),
        avg_days_to_close=("days_to_close", "mean"),
    )
    g["win_rate_pct"] = g.won / g.deals * 100
    g["ci95_low"], g["ci95_high"] = wilson(g.won, g.deals)
    g["avg_won_value"] = g.won_value / g.won.replace(0, np.nan)
    return g.sort_values("won_value", ascending=False).reset_index()


def win_rate_tests(c, dims):
    rows = []
    for d in dims:
        table = pd.crosstab(c[d], c.won)
        _, p, dof, expected = chi2_contingency(table)
        rows.append((d, len(table), dof, p, expected.min()))
    return pd.DataFrame(rows, columns=["dimension", "groups", "dof", "p_value", "min_expected_count"])


def loss_reasons(c):
    g = c.loc[~c.won, "loss_reason"].value_counts().rename("lost_deals").to_frame()
    g["share_pct"] = g.lost_deals / g.lost_deals.sum() * 100
    return g.reset_index()


def days_to_close_by_quarter(c, date_col):
    g = c.groupby(c[date_col].dt.to_period("Q").astype(str))["days_to_close"].agg(["size", "mean", "median"])
    return g.rename_axis("quarter").reset_index()


def resolution_by(s, dim):
    g = s.groupby(dim).agg(
        tickets=("resolution_hours", "size"),
        resolved=("resolution_hours", "count"),
        median_hours=("resolution_hours", "median"),
        mean_hours=("resolution_hours", "mean"),
    )
    g["unresolved"] = g.tickets - g.resolved
    return g.sort_values("median_hours", ascending=False).reset_index()


def product_area(s):
    g = s.groupby("product_area").agg(
        tickets=("product_area", "size"),
        high_or_critical=("priority", lambda x: x.isin(["high", "critical"]).sum()),
        users_affected=("users_affected", "sum"),
        downtime_minutes=("downtime_minutes", "sum"),
    )
    g["high_or_critical_pct"] = g.high_or_critical / g.tickets * 100
    return g.sort_values("tickets", ascending=False).reset_index()


def sentiment(s):
    g = s.customer_sentiment.fillna("blank").value_counts().rename("tickets").to_frame()
    g["share_pct"] = g.tickets / len(s) * 100
    return g.reset_index()


def account_summary(t):
    """Aggregate each source to one row per account BEFORE joining."""
    c, m, s = t["crm"], t["mkt"], t["sup"]
    a = c.groupby("account_id").agg(
        company_name=("company_name", "first"), company_size_tier=("company_size_tier", "first"),
        deals=("won", "size"), won_deals=("won", "sum"), won_value=("deal_value", "sum"),
    )
    mk = m.groupby("account_id").agg(
        leads=("lead_id", "size"), campaign_spend=("campaign_spend", "sum"),
        revenue_attributed=("revenue_attributed", "sum"),
    )
    sp = s.groupby("account_id").agg(
        tickets=("account_id", "size"),
        negative_tickets=("customer_sentiment", lambda x: (x == "negative").sum()),
        rated_tickets=("customer_sentiment", "count"),
        high_or_critical=("priority", lambda x: x.isin(["high", "critical"]).sum()),
    )
    sp["negative_pct"] = sp.negative_tickets / sp.rated_tickets * 100
    out = a.join(mk, how="left", validate="one_to_one").join(sp, how="left", validate="one_to_one")
    counts = ["leads", "campaign_spend", "revenue_attributed", "tickets", "negative_tickets", "rated_tickets", "high_or_critical"]
    out[counts] = out[counts].fillna(0)
    return out.reset_index()


def at_risk(a, q=0.75):
    """High value AND high ticket volume AND above-median negative sentiment."""
    flag = (
        (a.won_value >= a.won_value.quantile(q))
        & (a.tickets >= a.tickets.quantile(q))
        & (a.negative_pct > a.negative_pct.median())
    )
    return a[flag].sort_values("won_value", ascending=False)
