# Resubmission package

**Status: not ready to submit.** The items marked "You" need work in your own QuickSight session.

| Reviewer gap | Required evidence | Prepared here | You |
|---|---|---|---|
| No dashboard of your own | 3 sheets, KPI cards, filters, actions, PDF export | [Build guide](01_build_guide.md) | Build, publish, export to `export/` |
| Blank logs, no Chat/Topic screenshots | Both logs and screenshots | [Verification log](logs/verification_log.md), [Q log](logs/q_exploration_log.md) | Ask the questions, record actual answers, capture |
| No data preparation evidence | SPICE imports, types, calculated fields, join diagrams, saved datasets | Build guide, Part A | Perform and capture |
| Report not addressed to Sarah Chen | Findings, design rationale, topic effects, AI vs dashboard | [Report draft](report_to_sarah_chen.md) | Complete every `[FILL]` |

The reviewer mentions five criteria. This package follows the reviewer's comments, the starter templates and the requirements brief. **Check the official rubric before submitting.**

## Before you upload

- [ ] Screenshots listed in [`screenshots/README.md`](screenshots/README.md) are from your own session
- [ ] Both logs have your name, date, actual answers and match results
- [ ] Reflection is in your own words
- [ ] Dashboard PDF is in `export/`
- [ ] `grep -rn "\[FILL" submission --include=*.md --exclude=README.md` returns nothing
- [ ] Report describes only what you built and observed
- [ ] You have checked the course rules on AI assistance and followed any disclosure requirement
- [ ] Every required file is included; earlier uploads are not carried over
