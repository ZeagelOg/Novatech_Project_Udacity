-- One row per CRM account. Each source is aggregated BEFORE joining, so no sum is multiplied.
-- Tables: crm, mkt, sup (SQLite dialect).
WITH deals AS (
    SELECT account_id,
           MIN(company_name)  AS company_name,
           COUNT(*)           AS deals,
           SUM(CASE WHEN deal_stage = 'Won' THEN 1 ELSE 0 END) AS won_deals,
           SUM(deal_value)    AS won_value
    FROM crm
    GROUP BY account_id
),
marketing AS (
    SELECT account_id,
           COUNT(*)                AS leads,
           SUM(campaign_spend)     AS campaign_spend,
           SUM(revenue_attributed) AS revenue_attributed
    FROM mkt
    GROUP BY account_id
),
support AS (
    SELECT account_id,
           COUNT(*) AS tickets,
           SUM(CASE WHEN customer_sentiment = 'negative' THEN 1 ELSE 0 END) AS negative_tickets
    FROM sup
    GROUP BY account_id
)
SELECT d.*,
       COALESCE(m.leads, 0)              AS leads,
       COALESCE(m.campaign_spend, 0)     AS campaign_spend,
       COALESCE(m.revenue_attributed, 0) AS revenue_attributed,
       COALESCE(s.tickets, 0)            AS tickets,
       COALESCE(s.negative_tickets, 0)   AS negative_tickets
FROM deals d
LEFT JOIN marketing m ON m.account_id = d.account_id
LEFT JOIN support  s ON s.account_id = d.account_id
ORDER BY d.won_value DESC;
