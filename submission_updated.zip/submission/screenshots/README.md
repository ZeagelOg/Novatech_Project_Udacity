# Screenshot checklist
All must come from your own QuickSight session. Add suffixes (`_2`, `_3`) if one screen is not enough.

| Area | File names |
|---|---|
| Imports with row and column counts | `A1a_import_crm.png`, `A1b_import_marketing.png`, `A1c_import_support.png` |
| SPICE datasets | `A1_spice_datasets.png` |
| Type corrections | `A2_types_crm.png`, `A3_types_marketing.png`, `A4_types_support.png` |
| Calculated fields | `A5_calculated_fields.png` (show at least `days_to_close` and `campaign_roi`) |
| Joins | `A6_account_dim.png`, `A7_join_marketing.png`, `A8_join_support.png`, `A9_unified_join_diagram.png`, `A9b_unified_join_config.png`, `A10_unified_preview_rowcount.png` |
| Four required datasets saved | `A11_saved_datasets.png` |
| Dashboard | `B1_marketing_funnel.png`, `B2_sales_pipeline.png`, `B3_customer_health.png` |
| Filters | `B4_filter_before.png`, `B5_filter_after.png` (repeat on a second sheet) |
| Two filter actions | `B6_action_setup.png`, `B7_action_result.png` (one pair per visual) |
| Drill-down and published | `B8_drilldown.png`, `B9_published.png` |
| Navigation | `B10_navigation_setup.png`, `B11_navigation_source.png`, `B12_navigation_destination.png` |
| Verification and cross-check | `C1_verify.png` to `C7_verify.png`, `C8_crosscheck.png` |
| Before Topic | `C9_before_q1.png` to `C13_before_q5.png` |
| Topic setup | `C14_topic_setup.png` |
| After Topic | `C15_after_q1.png` to `C19_after_q5.png` |
