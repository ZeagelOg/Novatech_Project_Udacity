"""Expected values for checking a QuickSight build. Run: python -m src.expected"""
from . import metrics as mx
from .data import load

t = load()
c, m, s = t["crm"], t["mkt"], t["sup"]
dim = c[["account_id", "company_name", "industry", "company_size_tier"]].drop_duplicates()
me = m.merge(dim, on="account_id", how="left", validate="many_to_one")
se = s.merge(dim, on="account_id", how="left", validate="many_to_one")
acc = mx.account_summary(t)


def show(title, obj):
    print(f"\n## {title}\n{obj}")


show("Row counts: account_dim, marketing_enriched, support_enriched, unified",
     (len(dim), len(me), len(se), len(acc)))
show("Rows without an account match: marketing, support",
     (int(me.company_name.isna().sum()), int(se.company_name.isna().sum())))
show("Conversion (Closed Won share) by channel",
     mx.marketing_by(m, "campaign_channel")[["campaign_channel", "closed_won_share_pct"]].to_string(index=False))
show("Deal size by company size", c.groupby("company_size_tier").agg(
    all_deals=("deal_value", "mean")).join(c[c.won].groupby("company_size_tier").deal_value.mean().rename("won_only")).round(2).to_string())
show("Resolution hours by priority", mx.resolution_by(s, "priority").round(2).to_string(index=False))
show("Resolution hours by product", mx.resolution_by(s, "product_area").sort_values("mean_hours", ascending=False).round(2).to_string(index=False))
show("Top 10 accounts by tickets (CRM accounts)", acc.nlargest(10, "tickets")[["account_id", "company_name", "tickets", "won_value"]].to_string(index=False))
show("Top 10 account IDs by tickets (all support rows)", s.account_id.value_counts().head(10).to_string())
camp = mx.marketing_by(m, "campaign_name")
show("Campaigns where spend > revenue", camp.loc[camp.spend > camp.revenue, ["campaign_name", "spend", "revenue"]].to_string(index=False))
show("Reference docs: CRM accounts, sales reps", (c.account_id.nunique(), c.sales_rep.nunique()))
ent = se[se.company_size_tier.eq("Enterprise") & se.customer_sentiment.eq("negative")]
show("Enterprise accounts with at least one negative ticket", ent.account_id.nunique())
hi = s.loc[s.tickets_last_30_days > 3, "account_id"].unique()
sub = c[c.account_id.isin(hi)]
show("Accounts with any ticket row where tickets_last_30_days > 3: accounts, avg all, avg won",
     (sub.account_id.nunique(), round(sub.deal_value.mean(), 2), round(sub[sub.won].deal_value.mean(), 2)))
rule = acc[(acc.won_value >= 12716) & (acc.tickets >= 37) & (acc.negative_pct > 21.665)]
show("At-risk rule with fixed thresholds", (len(rule), rule.won_value.sum(), sorted(rule.account_id)))
