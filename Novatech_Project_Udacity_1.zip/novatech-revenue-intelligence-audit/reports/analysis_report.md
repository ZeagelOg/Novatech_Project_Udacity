# Corrected analysis

Every figure comes from `run_analysis.py`. Detailed results are in [`tables/`](tables/).

## Data coverage

| Source | Rows | Dates |
|---|---|---|
| CRM | 499 deals, all closed | created 17 Jun 2023 to 25 Jan 2025; closed 3 Dec 2023 to 31 Jan 2025 |
| Marketing | 2,240 leads | 1 Jan 2023 to 31 Jan 2025 |
| Support | 3,000 tickets (59 unresolved) | created 1 Jun 2023 to 28 Feb 2025 |

The windows differ, so cross-source totals do not describe the same period.

## 1. Marketing

| Channel | Leads | Response % | Closed Won share % | Spend | Attributed revenue | ROI % |
|---|---|---|---|---|---|---|
| Direct Mail | 149 | 53.0 | 49.0 | $721K | $211K | -70.7 |
| Partner Referral | 807 | 34.3 | 31.1 | $7.27M | $677K | -90.7 |
| Paid Social | 325 | 40.3 | 22.8 | $2.34M | $180K | -92.3 |
| Email | 288 | 8.7 | 2.8 | $490K | $25K | -94.9 |
| Organic Search | 671 | 14.5 | 0.9 | $1.54M | $34K | -97.8 |

| Campaign | Leads | Response % | Closed Won share % | ROI % |
|---|---|---|---|---|
| NovaPulse Launch | 409 | 35.2 | 33.7 | -83.7 |
| Year-End Accelerator | 340 | 17.4 | 17.4 | -90.8 |
| Enterprise Expansion | 389 | 27.8 | 20.6 | -90.8 |
| Digital Retarget | 419 | 34.8 | 16.2 | -91.9 |
| Q3 Growth Sprint | 410 | 32.9 | 12.9 | -93.3 |
| NovaEdge Awareness | 273 | 6.2 | 5.1 | -97.7 |

**Funnel:** assuming the stages are ordered and show each lead's current stage, the share at or beyond each stage is Lead 82.0%, Qualified Lead 61.2%, Opportunity 23.3% and Closed Won 18.4%. This is a snapshot, not tracked cohort conversion.

**Interpretation:** these are descriptive comparisons. Channels and campaigns have different lead mixes, so they do not show what moving budget would cause.

## 2. Sales

| Region | Deals | Win rate % (95% interval) | Won value | Average won deal |
|---|---|---|---|---|
| Central | 206 | 69.9 (63.3–75.8) | $274,285 | $1,905 |
| West | 165 | 58.8 (51.2–66.0) | $248,243 | $2,559 |
| East | 128 | 57.8 (49.2–66.0) | $184,673 | $2,496 |

Central's higher value comes with the smallest average won deal of the three regions.

**Statistical screen** (chi-square, unadjusted): region p = 0.031; manager p = 0.004; product p = 0.065; company size p = 0.855; rep p = 0.010. The rep and product tests have expected cell counts below 5, so their p-values are unreliable. With five tests, a Bonferroni threshold is 0.01. Manager passes it; region does not. Brian Nakamura (50.0%, n = 92) and Michael Chen (51.4%, n = 74) trail David Kim (70.8%, n = 113). Territory and deal mix may explain differences, so this is not a performance ranking.

**Revenue mix:** NovaPulse $548,560 (77.6%). Enterprise NovaPulse is the largest size-by-product group at $252,816 (35.7%). `company_size_tier` is used as the CRM segment.

**Sales reps:** Owen McCarthy has the most won value ($71,945, 43 deals). Many reps have few deals; read the intervals in `tables/sales_by_sales_rep.csv`.

**Loss reasons (184 losses):** No Decision Made 43, Poor Product Fit 43, Competitor Won 34, Timing Not Right 33, Budget Constraints 31.

**Days to close:** 66.8 on average (won 71.9, lost 57.9). The trend is **inconclusive**. Quarterly medians swing widely. Grouping by creation quarter is biased because the file contains only closed deals, and recent deals have had little time to take long.

## 3. Customer health

| Priority | Tickets | Unresolved | Median resolution (h) | Mean (h) |
|---|---|---|---|---|
| Critical | 50 | 2 | 50.5 | 56.6 |
| High | 400 | 9 | 50.1 | 58.1 |
| Medium | 1,050 | 13 | 50.6 | 58.0 |
| Low | 1,500 | 35 | 52.9 | 59.4 |

Resolution times use resolved tickets only. The similar times are a reason to **check how priority is used in triage**. They do not by themselves prove a process failure. SLA targets are not provided.

| Product area | Tickets | High/critical % | Users affected | Downtime (min) |
|---|---|---|---|---|
| Notifications | 601 | 11.1 | 77,080 | 9,995 |
| Analytics Dashboard | 597 | 2.7 | 69,233 | 4,116 |
| Authentication | 582 | 26.8 | 270,731 | 12,188 |
| Mobile App | 581 | 6.4 | 84,524 | 5,480 |
| Billing | 329 | 15.5 | 69,112 | 4,015 |
| Data Pipeline | 310 | 39.7 | 187,877 | 11,461 |

`users_affected` is summed per ticket, so one user may be counted more than once. Data Pipeline has the longest median resolution (53.6 h), but all areas fall within about 4 hours of each other.

## 4. Accounts: value and support load

- Across 85 CRM accounts, won value and ticket count have a Spearman correlation of 0.31. This is a weak positive association.
- The 10 accounts with the most tickets hold $154,709 of won value (21.9%).

**Screening rule:** won value and ticket count both in the top quarter (at least $12,716 and 37 tickets), plus a negative-sentiment share above the account median (21.7%).

| Account | Company | Won value | Tickets | Negative % |
|---|---|---|---|---|
| ACCT-011 | Falcon Software | $20,912 | 37 | 41.7 |
| ACCT-062 | StoneHarbor Medical | $17,362 | 49 | 27.1 |
| ACCT-035 | TrueNorth Electronics | $16,747 | 180 | 26.1 |
| ACCT-076 | LionGate Holdings | $16,275 | 176 | 22.2 |
| ACCT-060 | RedCedar Software | $15,780 | 142 | 25.0 |
| ACCT-024 | PeakVista Capital | $15,381 | 46 | 21.7 |
| ACCT-037 | Vanguard Marketing Group | $14,669 | 39 | 23.1 |
| ACCT-072 | HavenCrest Communications | $13,789 | 90 | 31.1 |

The median cut-off is relative: some flagged accounts are near the 22.8% all-ticket negative share. The rule uses the whole period, ignores recency and has not been tested against churn. Relaxing both top-quarter cut-offs to the top third adds PrimeCell Medical.

## 5. Recommended next steps

1. **Fix the data model** before anyone uses the dashboard totals.
2. **Define attribution.** Ask how `revenue_attributed` and `campaign_spend` are calculated, and add a lead-to-opportunity key.
3. **Review the 8 flagged accounts** with their account owners, starting with Falcon Software's negative share.
4. **Check triage rules and SLAs** against the priority-level resolution times.
5. **Investigate Authentication and Data Pipeline** reliability.
6. **Review lost-deal notes** for No Decision Made and Poor Product Fit.

## Limitations

- Course-scenario data; results should not be generalised to real companies. The company profile cites about $50M annual revenue, far above the $707K won value in the CRM file, and the file's scope is not explained.
- All comparisons are descriptive. No causal claims or forecasts.
- Reused deal and ticket IDs appear under different accounts. Rows are treated as separate records, which is an assumption.
- Natural-language querying from the brief was not rebuilt or tested.
