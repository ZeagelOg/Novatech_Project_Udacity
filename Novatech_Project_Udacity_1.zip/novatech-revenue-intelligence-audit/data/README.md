# Data

The raw files are course materials and are **not redistributed** in this repository.

Source: `project-starter-resources.zip` in
[Chiragchhabra1127/revenue-intelligence-dashboard](https://github.com/Chiragchhabra1127/revenue-intelligence-dashboard)
(reviewed at commit `c891ad4`).

Copy these three files from `Structured Data/` into `data/raw/`:

| File | Rows | Grain |
|---|---|---|
| `novatech_crm_deals.csv` | 499 | one row per closed deal |
| `novatech_marketing_campaigns.csv` | 2,240 | one row per marketing lead |
| `novatech_support_tickets.csv` | 3,000 | one row per support ticket |
