# Screenshot checklist
All must come from your own QuickSight session. Do not reuse anyone else's.

**Data preparation:** A1 SPICE datasets; A2–A4 type changes; A5 calculated fields; A6 account dimension; A7–A8 enrichment joins; A9 unified join diagram; A10 unified preview with row count; A11 saved datasets.

**Dashboard:** B1 Marketing Funnel; B2 Sales Pipeline; B3 Customer Health; B4–B5 shared filter before and after; B6–B7 action before and after; B8 drill-down; B9 published dashboard.

**Quick Chat and Topic:** C1–C7 verification answers; C8 dataset-preview cross-check; C9–C13 baseline answers; C14 Topic settings; C15–C19 answers after Topic.
