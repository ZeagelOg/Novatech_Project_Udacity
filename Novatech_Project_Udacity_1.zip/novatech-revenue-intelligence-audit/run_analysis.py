"""Run the full pipeline:  python run_analysis.py"""
import json
from src import audit, charts, metrics as mx
from src.data import ROOT, load, quality_checks

TABLES = ROOT / "reports" / "tables"


def main():
    t = load()
    c, m, s = t["crm"], t["mkt"], t["sup"]
    acc = mx.account_summary(t)
    out = {
        "data_quality": quality_checks(t),
        "audit_reconciliation": audit.reconciliation(t),
        "audit_roi_by_campaign": audit.roi_by_campaign_compare(t),
        "audit_response_rate": audit.response_rate_compare(t),
        "marketing_by_channel": mx.marketing_by(m, "campaign_channel"),
        "marketing_by_campaign": mx.marketing_by(m, "campaign_name"),
        "marketing_funnel": mx.funnel_snapshot(m),
        **{f"sales_by_{d}": mx.sales_by(c, d) for d in
           ["sales_region", "sales_rep", "sales_manager", "product_name", "product_category", "company_size_tier"]},
        "sales_segment_x_product": mx.sales_by(c, ["company_size_tier", "product_category"]),
        "sales_win_rate_tests": mx.win_rate_tests(c, ["sales_region", "sales_rep", "sales_manager", "product_name", "company_size_tier"]),
        "sales_loss_reasons": mx.loss_reasons(c),
        "sales_days_by_created_quarter": mx.days_to_close_by_quarter(c, "deal_created_date"),
        "sales_days_by_closed_quarter": mx.days_to_close_by_quarter(c, "deal_closed_date"),
        "support_resolution_by_priority": mx.resolution_by(s, "priority"),
        "support_resolution_by_product": mx.resolution_by(s, "product_area"),
        "support_product_area": mx.product_area(s),
        "support_sentiment": mx.sentiment(s),
        "account_summary": acc,
        "accounts_at_risk": mx.at_risk(acc),
        "accounts_at_risk_top_third": mx.at_risk(acc, 2 / 3),
        "accounts_top10_tickets": acc.nlargest(10, "tickets"),
    }
    TABLES.mkdir(parents=True, exist_ok=True)
    for name, df in out.items():
        df.to_csv(TABLES / f"{name}.csv", index=False, float_format="%.4f")
    summary = {k: round(float(v), 2) for k, v in mx.headline(t).items()}
    summary["corr_won_value_vs_tickets_spearman"] = round(float(acc.won_value.corr(acc.tickets, method="spearman")), 3)
    summary["fanout_join_rows"] = len(audit.fanout_join(t))
    (TABLES / "headline.json").write_text(json.dumps(summary, indent=2))
    charts.make_all(out)
    return out, summary


if __name__ == "__main__":
    out, summary = main()
    print(json.dumps(summary, indent=2))
    for k, v in out.items():
        if k != "account_summary":
            print(f"\n## {k}\n{v.to_string(index=False)}")
