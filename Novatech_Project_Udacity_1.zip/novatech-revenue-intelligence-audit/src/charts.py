"""Static PNG figures for the README and reports."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from .data import ROOT

FIG = ROOT / "reports" / "figures"
SURFACE, INK, MUTED, GRID = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
BLUE, ORANGE = "#2a78d6", "#eb6834"

plt.rcParams.update({
    "figure.facecolor": SURFACE, "axes.facecolor": SURFACE, "savefig.facecolor": SURFACE,
    "text.color": INK, "axes.labelcolor": MUTED, "xtick.color": MUTED, "ytick.color": INK,
    "axes.edgecolor": GRID, "font.size": 10.5,
})


def _frame(title, height=4.2):
    fig, ax = plt.subplots(figsize=(9, height))
    ax.set_title(title, loc="left", fontsize=13, fontweight="bold", pad=14)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.grid(axis="x", color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.tick_params(length=0)
    return fig, ax


def _save(fig, name):
    FIG.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(FIG / name, dpi=180)
    plt.close(fig)


def compare(df, label, before, after, title, xlabel, name):
    d = df.sort_values(after).reset_index(drop=True)
    fig, ax = _frame(title)
    y = np.arange(len(d))
    ax.barh(y + 0.19, d[before], 0.34, color=ORANGE, label="Fan-out join (as on dashboard)")
    ax.barh(y - 0.19, d[after], 0.34, color=BLUE, label="Raw table (corrected)")
    for pos, col in [(0.19, before), (-0.19, after)]:
        for i, v in enumerate(d[col]):
            ax.annotate(f"{v:.1f}%", (v, i + pos), xytext=(4 if v >= 0 else -4, 0),
                        textcoords="offset points", va="center", ha="left" if v >= 0 else "right", fontsize=9)
    ax.set_yticks(y, d[label])
    ax.set_xlabel(xlabel)
    lo, hi = min(d[[before, after]].min().min(), 0), max(d[[before, after]].max().max(), 0)
    ax.set_xlim(lo * 1.13, hi * 1.13 if hi else 0)
    ax.legend(loc="upper center", bbox_to_anchor=(0.4, -0.16), ncol=2, frameon=False)
    _save(fig, name)


def bars(labels, values, title, xlabel, fmt, name):
    fig, ax = _frame(title, 0.5 * len(labels) + 1.5)
    ax.barh(labels, values, 0.62, color=BLUE)
    ax.invert_yaxis()
    for i, v in enumerate(values):
        ax.annotate(fmt.format(v), (v, i), xytext=(5, 0), textcoords="offset points", va="center")
    ax.set_xlim(0, max(values) * 1.16)
    ax.set_xlabel(xlabel)
    _save(fig, name)


def make_all(out):
    compare(out["audit_roi_by_campaign"], "campaign_name", "fanout_join_roi_pct", "raw_roi_pct",
            "The join changes the campaign ROI ranking", "ROI % (closer to zero is better)", "01_roi_by_campaign.png")
    compare(out["audit_response_rate"], "campaign_channel", "fanout_join_pct", "raw_pct",
            "The join distorts response rate by channel", "Response rate %", "02_response_rate.png")
    ch = out["marketing_by_channel"].sort_values("spend_per_closed_won_lead")
    bars(ch.campaign_channel, ch.spend_per_closed_won_lead, "Spend per Closed Won lead, by channel",
         "USD of campaign spend per Closed Won lead (lower is better)", "${:,.0f}", "03_spend_per_closed_won.png")

    r = out["sales_by_sales_region"].sort_values("win_rate_pct", ascending=False).reset_index(drop=True)
    fig, ax = _frame("Win rate by region, with 95% intervals", 3.1)
    y = np.arange(len(r))
    ax.errorbar(r.win_rate_pct, y, xerr=[r.win_rate_pct - r.ci95_low, r.ci95_high - r.win_rate_pct],
                fmt="o", color=BLUE, ms=8, lw=2, capsize=4)
    for i, row in r.iterrows():
        ax.annotate(f"{row.win_rate_pct:.1f}%  (n={row.deals})", (row.win_rate_pct, i),
                    xytext=(0, 9), textcoords="offset points", ha="center")
    ax.set_yticks(y, r.sales_region)
    ax.set_ylim(len(r) - 0.5, -0.6)
    ax.set_xlim(40, 85)
    ax.set_xlabel("Win rate % (axis starts at 40)")
    _save(fig, "04_win_rate_region.png")

    p = out["support_resolution_by_priority"].set_index("priority").loc[["critical", "high", "medium", "low"]]
    bars([i.title() for i in p.index], p.median_hours, "Median resolution time barely changes with priority",
         "Median hours, resolved tickets only", "{:.1f} h", "05_resolution_by_priority.png")
    a = out["support_product_area"].sort_values("high_or_critical_pct", ascending=False)
    bars(a.product_area, a.high_or_critical_pct, "Share of tickets rated high or critical",
         "% of each product area's tickets", "{:.1f}%", "06_severity_by_product.png")
