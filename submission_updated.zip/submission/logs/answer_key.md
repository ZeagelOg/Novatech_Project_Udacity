# Answer key for checking (calculated from the CSVs)

These are **not** Q's answers or your dashboard readings. Record what you actually see.

| Q | Value from the raw files | Definition to watch |
|---|---|---|
| 1 | Direct Mail, 49.0% | `Closed Won` leads / all leads in the channel (marketing stage, not CRM wins) |
| 2 | All deals: Enterprise $1,589; Large $1,257; Medium $1,353; Small $1,486. Won only: $2,515; $2,042; $2,007; $2,230 | All-deal averages include lost deals as 0 |
| 3 | Mean: critical 56.6 h, low 59.4 h. Median: 50.5 h, 52.9 h | Resolved tickets only |
| 5 | All six campaigns | Spend greater than attributed revenue |

Question 4 (won value is the deal revenue):

| Account | Company | Tickets | Won value |
|---|---|---|---|
| ACCT-041 | YieldMax Software | 334 | $40,722 |
| ACCT-035 | TrueNorth Electronics | 180 | $16,747 |
| ACCT-076 | LionGate Holdings | 176 | $16,275 |
| ACCT-043 | AlphaCore Technologies | 171 | $14,874 |
| ACCT-060 | RedCedar Software | 142 | $15,780 |
| ACCT-036 | UltraLink Communications | 140 | $7,950 |
| ACCT-020 | MapleCrest Retail | 109 | $6,006 |
| ACCT-072 | HavenCrest Communications | 90 | $13,789 |
| ACCT-025 | PineRidge Global | 89 | $13,592 |
| ACCT-018 | LakeView Software | 83 | $8,974 |

Total won value of these 10: $154,709.

## Other natural-language questions in the brief
- **Win rate for Partner Referral deals:** the files have no lead-to-deal key, so deals cannot be assigned to a channel reliably. A confident number from Q needs scrutiny.
- **Product area with longest resolution:** Data Pipeline (mean 59.7 h), narrowly.
- **Deal size for accounts with more than 3 tickets in the last 30 days:** `tickets_last_30_days` is stored per ticket, so the account rule must be defined first.
